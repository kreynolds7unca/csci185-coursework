function showFox() {
    // your code here...
    console.log('Change image and paragraph to fox...');
    document.querySelector('.card').src="images/fox.jpg";

}

function showLion() {
    // your code here...
    console.log('Change image and paragraph to lion...');
    document.querySelector('.card').src="images/lion.jpg";
}

function showTiger() {
    // your code here...
    console.log('Change image and paragraph to tiger...');
    document.querySelector('.card').src="images/tiger.jpg";
}

function showZebra() {
    // your code here...
    console.log('Change image and paragraph to zebra...');
    document.querySelector('.card').src="images/zebra.jpg";
}

